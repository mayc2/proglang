We coulnd't get alpha renmaning but what we have is at the top of our program, uncalled.

Beta works for some of it, we divided everything into tuples.
