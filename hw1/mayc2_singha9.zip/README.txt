Chris May(mayc2), Avi Singh(singha9)

All three parts are working.

Only extra feature in part III is that we handled statments to the database command that had a determiner of 'a' or 'the' and avoiding a determiner of 'every' for the database command input.

